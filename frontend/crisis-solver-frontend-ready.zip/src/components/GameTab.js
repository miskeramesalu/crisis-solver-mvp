import React, { useState } from "react";
import { submitGame } from "../api";

const GameTab = () => {
  const [score, setScore] = useState(0);
  const [status, setStatus] = useState("");

  const handleSubmit = async () => {
    try {
      await submitGame({ userId: "user123", gameId: "game1", score });
      setStatus("✅ Score submitted!");
    } catch {
      setStatus("❌ Failed to submit score.");
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Mini Game</h2>
      <p>Your current score: {score}</p>
      <button
        onClick={() => setScore(score + 10)}
        className="mt-3 px-3 py-2 bg-green-600 text-white rounded-md"
      >
        +10 Points
      </button>
      <button
        onClick={handleSubmit}
        className="ml-3 px-3 py-2 bg-blue-600 text-white rounded-md"
      >
        Submit
      </button>
      <p className="mt-3 text-sm text-gray-500">{status}</p>
    </div>
  );
};

export default GameTab;
