import React from "react";

const tabs = [
  { key: "dashboard", label: "Dashboard" },
  { key: "quiz", label: "Quiz" },
  { key: "game", label: "Game" },
  { key: "donation", label: "Donation" },
  { key: "referral", label: "Referral" },
  { key: "media", label: "Media" },
  { key: "leaderboard", label: "Leaderboard" },
];

const Navbar = ({ activeTab, setActiveTab }) => {
  return (
    <nav className="bg-blue-600 text-white flex justify-around py-3 shadow-md">
      {tabs.map((tab) => (
        <button
          key={tab.key}
          onClick={() => setActiveTab(tab.key)}
          className={`px-3 py-2 rounded-md text-sm font-medium ${activeTab === tab.key ? "bg-blue-800" : "hover:bg-blue-700"}`}
        >
          {tab.label}
        </button>
      ))}
    </nav>
  );
};

export default Navbar;
