import React, { useState } from "react";
import { submitDonation } from "../api";

const DonationTab = () => {
  const [amount, setAmount] = useState("");
  const [status, setStatus] = useState("");

  const handleDonate = async () => {
    try {
      await submitDonation({ donorId: "user123", amount, currency: "USD" });
      setStatus("✅ Donation successful!");
    } catch {
      setStatus("❌ Donation failed.");
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Make a Donation</h2>
      <input
        type="number"
        placeholder="Amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        className="border p-2 rounded-md mr-2"
      />
      <button
        onClick={handleDonate}
        className="px-4 py-2 bg-blue-600 text-white rounded-md"
      >
        Donate
      </button>
      <p className="mt-3 text-sm text-gray-500">{status}</p>
    </div>
  );
};

export default DonationTab;
