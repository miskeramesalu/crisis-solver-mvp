import React, { useState } from "react";
import { submitQuiz } from "../api";

const QuizTab = () => {
  const [answers, setAnswers] = useState({});
  const [status, setStatus] = useState("");

  const handleSubmit = async () => {
    try {
      setStatus("Submitting...");
      await submitQuiz({ userId: "user123", quizId: "quiz1", answers });
      setStatus("✅ Quiz submitted successfully!");
    } catch {
      setStatus("❌ Submission failed.");
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Quiz</h2>
      <p className="mb-2 text-gray-600">Answer sample questions...</p>
      <button
        onClick={handleSubmit}
        className="px-4 py-2 bg-blue-600 text-white rounded-md"
      >
        Submit Quiz
      </button>
      <p className="mt-3 text-sm text-gray-500">{status}</p>
    </div>
  );
};

export default QuizTab;
