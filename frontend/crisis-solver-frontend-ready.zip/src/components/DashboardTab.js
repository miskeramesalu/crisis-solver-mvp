import React, { useEffect, useState } from "react";
import { fetchUserBalance } from "../api";

const DashboardTab = () => {
  const [balance, setBalance] = useState(0);
  const userId = "user123"; // placeholder (replace with dynamic auth if needed)

  useEffect(() => {
    const load = async () => {
      const bal = await fetchUserBalance(userId);
      setBalance(bal);
    };
    load();
  }, []);

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-3">Welcome to Crisis Solver</h2>
      <p className="text-gray-600 mb-2">User: {userId}</p>
      <p className="text-lg font-bold text-green-600">💰 Token Balance: {balance} CSOL</p>
    </div>
  );
};

export default DashboardTab;
