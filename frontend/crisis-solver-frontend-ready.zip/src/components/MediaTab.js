import React, { useState, useEffect } from "react";
import { fetchMedia, uploadMedia } from "../api";

const MediaTab = () => {
  const [media, setMedia] = useState([]);
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("");

  const loadMedia = async () => {
    const items = await fetchMedia();
    setMedia(items);
  };

  useEffect(() => { loadMedia(); }, []);

  const handleUpload = async () => {
    if (!file) return;
    try {
      setStatus("Uploading...");
      await uploadMedia({ file, title: file.name, description: "Uploaded by user123", uploaderId: "user123" });
      setStatus("✅ Uploaded!");
      loadMedia();
    } catch {
      setStatus("❌ Upload failed.");
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Media</h2>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={handleUpload} className="ml-2 px-4 py-2 bg-blue-600 text-white rounded-md">Upload</button>
      <p className="mt-3 text-sm text-gray-500">{status}</p>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-6">
        {media.map((m) => (
          <div key={m._id} className="border p-2 rounded-md">
            <p className="font-medium">{m.title}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MediaTab;
