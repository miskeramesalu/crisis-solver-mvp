import React, { useState } from "react";
import { submitReferral } from "../api";

const ReferralTab = () => {
  const [newUserId, setNewUserId] = useState("");
  const [status, setStatus] = useState("");

  const handleReferral = async () => {
    try {
      await submitReferral({ referrerId: "user123", newUserId });
      setStatus("✅ Referral submitted!");
    } catch {
      setStatus("❌ Failed to refer user.");
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Referral</h2>
      <input
        type="text"
        placeholder="New User ID"
        value={newUserId}
        onChange={(e) => setNewUserId(e.target.value)}
        className="border p-2 rounded-md mr-2"
      />
      <button
        onClick={handleReferral}
        className="px-4 py-2 bg-blue-600 text-white rounded-md"
      >
        Submit Referral
      </button>
      <p className="mt-3 text-sm text-gray-500">{status}</p>
    </div>
  );
};

export default ReferralTab;
